import { Component, OnInit } from '@angular/core';

@Component({
	selector : 'mobiles',
	template : `<h1>Mobile Component</h1>`
})

export class MobileComponent{
	constructor(){
	
	}
}