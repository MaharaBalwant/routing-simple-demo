import { Component, OnInit } from '@angular/core';

@Component({
	selector : 'shoes',
	template : `<h1>Shoes Component</h1>`
})

export class ShoeComponent{
	constructor(){
	
	}
}