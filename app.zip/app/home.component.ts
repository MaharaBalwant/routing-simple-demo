import { Component, OnInit } from '@angular/core';

@Component({
	selector : 'home',
	template : `<h1>Home Component</h1>`
})

export class HomeComponent{
	constructor(){
	
	}
}