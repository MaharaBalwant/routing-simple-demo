import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Data } from '@angular/router';

@Component({
	selector : 'error-page',
	template : `<h1>Error Page Component</h1><br/><h2>{{errorMessage}}</h2>`
})

export class ErrorPageComponent{

    errorMessage:string;

    constructor( private route:ActivatedRoute){	
    }
    ngOnInit() {
        this.errorMessage = this.route.snapshot.data['message'];
    }
}