import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header.component';
import { HomeComponent } from './home.component';
import { ShoeComponent } from './shoe.component';
import { MobileComponent } from './mobile.component';
import { ErrorPageComponent } from './error.page.component';
import { HeaderLeftComponent } from './header-left/header-left.component';

const routes = [
  {path:'shoes', component:ShoeComponent},
  {path:'mobiles',component:MobileComponent},
  {path:'', component:HomeComponent},
  { path: 'not-found', component: ErrorPageComponent, data: {message: 'Page not found!'} },
  { path: '**', redirectTo: '/not-found' }
  //{path:'**',redirectTo:'/'}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ShoeComponent,
    MobileComponent,
    ErrorPageComponent,
    HeaderLeftComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
