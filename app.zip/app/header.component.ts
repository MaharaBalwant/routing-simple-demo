import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector : 'header',
	template : `<ul><li><a [routerLinkActiveOptions]="{exact:true}" routerLinkActive="active" [routerLink]="'/'">Home</a></li>
					<li><a routerLinkActive="active"  routerLink="shoes">Shoes</a></li>
					<li><a routerLinkActive="active" routerLink="mobiles">Mobiles</a></li>
				</ul>`
})

export class HeaderComponent{
	constructor(private router:Router){
	
	}
}